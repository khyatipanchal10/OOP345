#include "iProduct.h"

namespace w7{
  class Sale{
    public:
      void display(std::ostream& os) const;
  };
}